"""
Core game logic for the Heilbronn Triangle Game.

All coordinates are in normalized unit-disk space (radius = 1).
"""

from __future__ import annotations

import itertools
import json
from typing import Any

import numpy as np
from scipy.optimize import minimize, dual_annealing


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

def triangle_area(p1, p2, p3) -> float:
    """Compute the area of a triangle using the shoelace formula."""
    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = p3
    return 0.5 * abs((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1))


def smallest_triangle(points) -> tuple:
    """
    Find the triple of points forming the triangle with minimum area.

    Returns (p1, p2, p3, area).
    """
    pts = list(points)
    if len(pts) < 3:
        raise ValueError("Need at least 3 points")

    min_area = float("inf")
    best = None
    for p1, p2, p3 in itertools.combinations(pts, 3):
        area = triangle_area(p1, p2, p3)
        if area < min_area:
            min_area = area
            best = (p1, p2, p3, area)
    return best


# ---------------------------------------------------------------------------
# Optimizer factories
# ---------------------------------------------------------------------------

def make_nelder_mead(params: dict = {}):
    """Return a Nelder-Mead optimizer callable."""
    def optimizer(objective, x0, bounds):
        options = params.get("options", {})
        return minimize(objective, x0, method="Nelder-Mead", options=options if options else None)
    return optimizer


def make_simulated_annealing(params: dict = {}):
    """Return a dual annealing optimizer callable."""
    recognized_keys = {
        "maxiter", "initial_temp", "restart_temp_ratio", "visit", "accept",
        "maxfun", "seed", "no_local_search", "minimizer_kwargs", "x0",
    }
    sa_kwargs = {k: v for k, v in params.items() if k in recognized_keys}

    def optimizer(objective, x0, bounds):
        return dual_annealing(objective, bounds, x0=x0, **sa_kwargs)
    return optimizer


def make_bayesian(params: dict = {}):
    """Return a Bayesian (GP) optimizer callable. Requires scikit-optimize."""
    def optimizer(objective, x0, bounds):
        try:
            from skopt import gp_minimize
        except ImportError:
            raise ImportError("scikit-optimize is not available in this environment")

        skopt_bounds = [(lo, hi) for lo, hi in bounds]
        result = gp_minimize(objective, skopt_bounds, x0=list(x0), **params)
        return result
    return optimizer


class _MetropolisResult:
    """Minimal result object compatible with scipy.OptimizeResult interface."""
    __slots__ = ("x",)

    def __init__(self, x: np.ndarray):
        self.x = x


def make_metropolis(params: dict = {}):
    """Return a Metropolis-Hastings sampler optimizer callable."""
    n_iterations = params.get("n_iterations", 5000)
    step_size = params.get("step_size", 0.05)

    def optimizer(objective, x0: np.ndarray, bounds):
        bounds_arr = np.array(bounds)
        lo = bounds_arr[:, 0]
        hi = bounds_arr[:, 1]

        x_current = np.array(x0, dtype=float)
        current_val = objective(x_current)

        best_x = x_current.copy()
        best_val = current_val

        T_start, T_end = 1.0, 0.01

        for i in range(n_iterations):
            T = T_start + (T_end - T_start) * (i / max(n_iterations - 1, 1))
            x_new = x_current + np.random.normal(0, step_size, size=x_current.shape)
            x_new = np.clip(x_new, lo, hi)

            new_val = objective(x_new)
            delta = new_val - current_val

            if delta < 0 or np.random.random() < np.exp(-delta / T):
                x_current = x_new
                current_val = new_val

            if current_val < best_val:
                best_val = current_val
                best_x = x_current.copy()

        return _MetropolisResult(best_x)
    return optimizer


OPTIMIZERS: dict[str, Any] = {
    "nelder-mead": make_nelder_mead,
    "simulated-annealing": make_simulated_annealing,
    "bayesian": make_bayesian,
    "metropolis": make_metropolis,
}


# ---------------------------------------------------------------------------
# Configuration optimization
# ---------------------------------------------------------------------------

def _decode(x: np.ndarray) -> list[tuple]:
    coords = x.reshape(-1, 2)
    return [tuple(p) for p in coords]


def optimal_configuration(starting_points, optimizer_fn) -> list[tuple]:
    """
    Optimize point placement to maximize the smallest triangle area.

    Returns the optimized list of (x, y) tuples.
    """
    pts = list(starting_points)
    x0 = np.array(pts, dtype=float).flatten()
    bounds = [(-1.0, 1.0)] * len(x0)

    def objective(x: np.ndarray) -> float:
        config = _decode(x)
        _, _, _, area = smallest_triangle(config)
        return -area

    result = optimizer_fn(objective, x0, bounds)
    return _decode(result.x)


def sample_random_disk_points(m: int) -> list[tuple]:
    """Sample M points uniformly at random inside the unit disk (rejection sampling)."""
    points = []
    while len(points) < m:
        batch = np.random.uniform(-1, 1, size=(m * 4, 2))
        inside = batch[batch[:, 0] ** 2 + batch[:, 1] ** 2 <= 1.0]
        for p in inside:
            points.append(tuple(p))
            if len(points) == m:
                break
    return points


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_scoring(
    player_points_json: str,
    optimizer_name: str = "nelder-mead",
    optimizer_params_json: str = "{}",
) -> str:
    """
    Score a player's point configuration against the optimizer's best.

    Parameters
    ----------
    player_points_json:
        JSON string encoding a list of [x, y] pairs (normalized unit-disk coords).
    optimizer_name:
        One of the keys in OPTIMIZERS.
    optimizer_params_json:
        JSON string encoding a dict of optimizer parameters (may be "{}").

    Returns
    -------
    JSON string with keys: score, num_points, player_triangle, optimal_triangle.
    """
    player_points = [tuple(p) for p in json.loads(player_points_json)]
    optimizer_params = json.loads(optimizer_params_json)

    if optimizer_name not in OPTIMIZERS:
        raise ValueError(
            f"Unknown optimizer '{optimizer_name}'. "
            f"Choose from: {list(OPTIMIZERS.keys())}"
        )

    optimizer_fn = OPTIMIZERS[optimizer_name](optimizer_params)
    m = len(player_points)

    # Player score
    p1, p2, p3, player_area = smallest_triangle(player_points)

    # Run A: optimize starting from player config
    opt_a = optimal_configuration(player_points, optimizer_fn)
    _, _, _, area_a = smallest_triangle(opt_a)

    # Run B: optimize starting from random disk points
    random_start = sample_random_disk_points(m)
    opt_b = optimal_configuration(random_start, optimizer_fn)
    _, _, _, area_b = smallest_triangle(opt_b)

    # Best of A and B
    if area_a >= area_b:
        best_config = opt_a
        optimal_area = area_a
    else:
        best_config = opt_b
        optimal_area = area_b

    # Score (clamped)
    if optimal_area <= 0:
        score = 1.0
    else:
        score = float(np.clip(player_area / optimal_area, 0.0, 1.0))

    opt_t1, opt_t2, opt_t3, _ = smallest_triangle(best_config)

    return json.dumps({
        "score": score,
        "num_points": m,
        "player_triangle": [list(p1), list(p2), list(p3)],
        "optimal_triangle": [list(opt_t1), list(opt_t2), list(opt_t3)],
    })
