from __future__ import annotations

import json

import numpy as np

from .api import cross_section


def run_cross_section(n: int, seed: int | None = None) -> str:
    """
    Compute a random cross-section and return a JSON string for the browser.

    Combines positive and antipodal vertices, sorts them counter-clockwise,
    and normalises by circumradius so the circumscribed circle has radius 1.

    Returns JSON with:
        vertices  - list of [x, y] pairs (CCW order, normalised)
        payout    - inradius / circumradius ratio
    """
    result = cross_section(n=n, seed=seed)

    all_verts = np.vstack([result.vertices, result.antipodal_vertices])
    angles = np.arctan2(all_verts[:, 1], all_verts[:, 0])
    sorted_verts = all_verts[np.argsort(angles)]
    normalized = (sorted_verts / result.circumradius).tolist()

    return json.dumps({
        "vertices": normalized,
        "payout": result.payout,
    })
